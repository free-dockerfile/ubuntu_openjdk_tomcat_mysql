#!/bin/bash

export JAVA_HOME=/usr/local/src/lib/java/default 
export CATALINA_HOME=/usr/local/src/lib/tomcat/default 
export ANT_HOME=/usr/local/src/lib/ant/default 
export PATH=/usr/local/src/lib/java/default/bin:/usr/local/src/lib/ant/default/bin:/usr/local/src/lib/tomcat/default/bin:$PATH
