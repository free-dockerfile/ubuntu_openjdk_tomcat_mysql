Image: ubuntu14_jdk8_tomcat8_mysql5
SSH Base User: sshuser
DB App User: dbappuser
DB Admin User: root 
DB Schema: appdb 
./change.sh SSH_BASE_PWD SSH_ADMIN_PWD DB_APP_PWD DB_ADMIN_PWD
